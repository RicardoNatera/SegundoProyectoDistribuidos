/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmicliente;

import entities.ship.Ship;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.util.LinkedList;
import server.serverinterface.ServerInterface;
/**
 *
 * @author suber
 */
public class RMICliente {

    static int puertoRMI = 12345;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.getSecurityManager();
        
        try {
            Registry registro = LocateRegistry.getRegistry("192.168.1.105",puertoRMI);//Aqui, cambiar 192.168.1.105 por la dirección ipv4 de la maquina que inicie el startregistry, es decir la primera maquina donde se ejecute el programa de server
            ServerInterface si;
            si = (ServerInterface) (registro.lookup("Servidor1"));
            
            System.out.println("Servidor1 encontrado");
            System.out.println("Enviando Barcos");
            LinkedList<String> listaNodos = new LinkedList<>();
            listaNodos.add("Servidor1");
            listaNodos.add("Servidor2");
            listaNodos.add("Servidor3");
            listaNodos.add("Servidor4");
            
            LinkedList<Ship> s = new LinkedList<>();
            
            //Aqui se añaden los 3 barcos
            s.add(new Ship(0,0,1,"La Venganza Errante","Pirata",listaNodos,puertoRMI));
            s.add(new Ship(0,0,2,"El HSM Invencible","Armada Real",listaNodos,puertoRMI));
            s.add(new Ship(0,0,2,"El HSM Interceptor","Armada Real",listaNodos,puertoRMI));
            //--------------------------------------------------------
            s.forEach((barco) -> {
                System.out.println("*****El Barco " +barco.getName() + " está saliendo.*****");
                Hilo hilo=new Hilo(barco,si);
                hilo.start();
            });
            
            System.out.println("Fin de la simulación");
            
        } catch (NotBoundException | RemoteException e) {
            System.out.println("Excepción en Main: "+e);
        }
        // TODO code application logic here
    }
    
}
