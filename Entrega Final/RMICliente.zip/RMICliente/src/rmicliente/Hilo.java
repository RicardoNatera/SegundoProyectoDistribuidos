/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmicliente;

import entities.ship.Ship;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import server.serverinterface.ServerInterface;

/**
 *
 * @author suber
 */
class Hilo implements Runnable{
    private final Ship ship;
    private final ServerInterface si;
    private Thread thread;

    public Hilo(Ship ship,ServerInterface si) {
        this.ship = ship;
        this.si=si;
        this.thread = new Thread();
    }
    
    @Override
    public void run() {
        try {
            si.recibe(ship);
            this.stop();
        } catch (RemoteException ex) {
            System.out.println("Error al ejecutar al barco "+ship.getName());        
        } catch (InterruptedException ex) {
            Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public synchronized void start(){
        //if(active) return;
        
        thread = new Thread(this);
        thread.start();
    }
    public synchronized void stop() throws InterruptedException{
        thread.join();
    }

    public Ship getShip() {
        return ship;
    }

    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }
}
