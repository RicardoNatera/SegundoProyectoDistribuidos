/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dev.piratasenelcaribe.client;

import dev.piratasenelcaribe.mouseinput.MouseManager;
import dev.piratasenelcaribe.worlds.World;

/**
 *
 * @author suber
 */
public class Handler {
    private Simulation simulation;
    private World world;
    public Handler(Simulation simulation) {
        this.simulation = simulation;
    }
    
    public MouseManager getMouseManager(){
        return simulation.getMouseManager();
    }
    public int getWidth(){
        return Simulation.getWidth();
    }
    
    public int getHeight(){
        return Simulation.getHeight();
    }

    public Simulation getSimulation() {
        return simulation;
    }

    public World getWorld() {
        return world;
    }

    public void setSimulation(Simulation simulation) {
        this.simulation = simulation;
    }

    public void setWorld(World world) {
        this.world = world;
    }
    
}
