/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dev.piratasenelcaribe.client;

import dev.piratasenelcaribe.client.gfx.Assets;
import dev.piratasenelcaribe.display.Display;
import dev.piratasenelcaribe.mouseinput.MouseManager;
import dev.piratasenelcaribe.states.MenuState;
import dev.piratasenelcaribe.states.SimulationState;
import dev.piratasenelcaribe.states.State;
import entities.ship.Ship;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author suber
 */
public class Simulation implements Runnable{
    private final String ID;
    private Display display; 
    static public int width,height;
    public String title;
    private boolean running=false;
    Ship pirata,real1,real2;

    private Thread thread;

    private BufferStrategy bs;
    private Graphics g;

    //States
    private State simulationState;
    private State menuState;
    
    private final MouseManager mouseManager;
    
    public static Handler handler;

    public void setPirata(Ship pirata) {
        this.pirata = pirata;
    }

    public void setReal1(Ship real1) {
        this.real1 = real1;
    }

    public void setReal2(Ship real2) {
        this.real2 = real2;
    }

    public Ship getPirata() {
        return pirata;
    }

    public Ship getReal1() {
        return real1;
    }

    public Ship getReal2() {
        return real2;
    }
    
    public Simulation(String title, int width,int height,String ID){
        Simulation.width=width;
        Simulation.height=height;
        this.title=title;
        mouseManager=new MouseManager();
        this.ID=ID;
        
        pirata=new Ship(0,0,1,"La Venganza Errante","Pirata",null,12345);
        real1=new Ship(0,0,2,"El HSM Invencible","Armada Real",null,12345);
        real2=new Ship(100,0,2,"El HSM Interceptor","Armada Real",null,12345);
    }
    
    private void init() throws RemoteException{
        display = new Display(title,width,height);
        display.getCanvas().addMouseListener(mouseManager);
        Assets.init();
        
        handler=new Handler(this);
        
        simulationState = new SimulationState(handler,ID);
        menuState = new MenuState(handler);
        State.setCurrentState(simulationState);
    }

    public MouseManager getMouseManager() {
        return mouseManager;
    }

    private void tick(){
        
        if(State.getCurrentState() != null){
            State.getCurrentState().tick();
        }
    }
    private void render(){
        bs = display.getCanvas().getBufferStrategy();
       if(bs == null){
           display.getCanvas().createBufferStrategy(3);
           return;
       }
       g = bs.getDrawGraphics();
       //Clear
       g.clearRect(0, 0, width, height);
       // Draw here
       if(State.getCurrentState() != null){
        State.getCurrentState().render(g);
       }
       //-----------
       bs.show();
       g.dispose();
       
    }
    
    @Override
    public void run() {
      
        try {
            init();
        } catch (RemoteException ex) {
            Logger.getLogger(Simulation.class.getName()).log(Level.SEVERE, null, ex);
        }

        int fps = 60;
        double timePerTick = 1000000000/fps;
        double delta=0;
        long now;
        long lastTime = System.nanoTime();
        long timer=0;
        long ticks=0;
        
        while (running) {
            now = System.nanoTime();
            delta += (now-lastTime)/timePerTick;
            timer+=now-lastTime;
            lastTime = now;
            
            if(delta>=1){
                tick();
                render();
                ticks++;
                delta--;
            }
            if(timer>=1000000000){
                //System.out.println("Ticks and frames: "+ticks);
                ticks=0;
                timer=0;
            }
        }

        try {
            stop();
        } catch (InterruptedException ex) {
            Logger.getLogger(Simulation.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    }
    
    public synchronized void start(){
        if(running) return;
        
        running = true;
        thread = new Thread(this);
        thread.start();
    }
    public synchronized void stop() throws InterruptedException{
        if(!running) return;
        
        running= false;
        thread.join();
    } 

    public static int getWidth() {
        return width;
    }

    public static int getHeight() {
        return height;
    }
}
