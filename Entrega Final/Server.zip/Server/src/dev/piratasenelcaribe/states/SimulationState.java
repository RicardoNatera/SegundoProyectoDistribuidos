/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dev.piratasenelcaribe.states;

import dev.piratasenelcaribe.client.Handler;
import dev.piratasenelcaribe.client.Simulation;
import dev.piratasenelcaribe.client.gfx.Assets;
import dev.piratasenelcaribe.worlds.World;
import entities.ship.Ship;
import java.awt.Graphics;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author suber
 */
public class SimulationState extends State{

    private final World world;
    //recuerda que tiene acceso a la variable simulation
    
    public SimulationState(Handler handler,String ID) throws RemoteException {
        super(handler);
        world = new World("res/worlds/cliente"+ID+".xml",Simulation.getWidth(),Simulation.getHeight(),handler);
        handler.setWorld(world);
        
        for(Ship ship:this.world.getBarcoInicial()){
            switch (ship.getName()) {
                case "La Venganza Errante" -> {
                    handler.getSimulation().getPirata().clone(ship);
                    handler.getSimulation().getPirata().setState("Viaje Iniciado");
                    handler.getSimulation().getPirata().setTexture(Assets.pirataD);
                    handler.getSimulation().getPirata().setHandler(handler);
                }
                case "El HSM Invencible" -> {
                    handler.getSimulation().getReal1().clone(ship);
                    handler.getSimulation().getReal1().setState("Viaje Iniciado");
                    handler.getSimulation().getReal1().setTexture(Assets.realD);
                    handler.getSimulation().getReal1().setHandler(handler);
                }
                default -> {
                    handler.getSimulation().getReal2().clone(ship);
                    handler.getSimulation().getReal2().setState("Viaje Iniciado");
                    handler.getSimulation().getReal2().setTexture(Assets.realD);
                    handler.getSimulation().getReal2().setHandler(handler);
                }
            }
        }
    }

    @Override
    public void tick() {
        world.tick(handler.getMouseManager().hoverX,handler.getMouseManager().hoverY);
        
        try {
            if(!"creado".equals(handler.getSimulation().getPirata().getState()) && handler.getSimulation().getPirata()!=null)
                handler.getSimulation().getPirata().tick(handler.getMouseManager().hoverX, handler.getMouseManager().hoverY, world.getWorldId());
            
            if(!"creado".equals(handler.getSimulation().getReal1().getState()) && handler.getSimulation().getReal1()!=null){
                handler.getSimulation().getReal1().tick(handler.getMouseManager().hoverX, handler.getMouseManager().hoverY, world.getWorldId());

            }
            
            if(!"creado".equals(handler.getSimulation().getReal2().getState()) && handler.getSimulation().getReal2()!=null)
                handler.getSimulation().getReal2().tick(handler.getMouseManager().hoverX, handler.getMouseManager().hoverY, world.getWorldId());
        } catch (RemoteException ex) {
            Logger.getLogger(SimulationState.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void render(Graphics g) {
        world.render(g);
        if(!"creado".equals(handler.getSimulation().getPirata().getState()) && handler.getSimulation().getPirata()!=null)
            handler.getSimulation().getPirata().render(g, world.getWorldId());
        if(!"creado".equals(handler.getSimulation().getReal1().getState()) && handler.getSimulation().getReal1()!=null){
            handler.getSimulation().getReal1().render(g, world.getWorldId());
        }
        if(!"creado".equals(handler.getSimulation().getReal2().getState()) && handler.getSimulation().getReal2()!=null)
            handler.getSimulation().getReal2().render(g, world.getWorldId());
        //g.drawImage(Assets.cofreA, 0, 0, 92,92,null);
        //g.drawImage(Assets.cofreA, 280, 280, 92,92,null);
        //g.drawImage(Assets.cofreA, 450, 70, 92,92,null);
        //g.drawImage(Assets.pirataD, 100, 100, 64,64,null);
    }   
}
