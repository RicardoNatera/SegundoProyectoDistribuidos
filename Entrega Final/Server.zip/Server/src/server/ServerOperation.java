/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;
import dev.piratasenelcaribe.client.Simulation;
import dev.piratasenelcaribe.utils.Utils;
import entities.ship.Ship;
//import java.io.*;
//import java.rmi.Naming;
//import java.rmi.server.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;
import java.util.LinkedList;

import javax.swing.JOptionPane;
import server.serverinterface.ServerInterface;
/**
 *
 * @author suber
 */

public class ServerOperation extends UnicastRemoteObject implements ServerInterface{
    private static final long serialVersionUID = 1L;
    static int puertoRMI = 12345;
    static Registry registro;
    static String miNombre= "Servidor";
    static String miNumero;
    private static Simulation simulation;
    
    protected ServerOperation() throws RemoteException {
        super();
    }
    
    @Override
    public void recibe(Ship s) throws RemoteException {
        System.out.println("*****El Barco " +s.getName() + " ha llegado.*****:"+s.getState()+s.getWorldID());
        
        if(s.getState().equals("creado") && s.getWorldID()==Utils.parseInt(miNumero)){//Es la primera vez que recibe al agente
            switch (s.getName()) {
                case "La Venganza Errante" -> s.clone(ServerOperation.simulation.getPirata());
                case "El HSM Invencible" -> s.clone(ServerOperation.simulation.getReal1());
                default -> s.clone(ServerOperation.simulation.getReal2());
            }
        }
        
        //El agente local está listo para viajar
        if(ServerOperation.simulation.getPirata().getState().equals("En espera para viajar") && s.getName().equals("La Venganza Errante")){//El pirata esta listo para irse
            s.clone(ServerOperation.simulation.getPirata());
            ServerOperation.simulation.getPirata().setState("Viajando");
            s.setState("Viajando");
            
        }
        if(ServerOperation.simulation.getReal1().getState().equals("En espera para viajar") && s.getName().equals("El HSM Invencible")){//El pirata esta listo para irse
            
            s.clone(ServerOperation.simulation.getReal1());
            ServerOperation.simulation.getReal1().setState("Viajando");
            s.setState("Viajando");
        }
        if(ServerOperation.simulation.getReal2().getState().equals("En espera para viajar") && s.getName().equals("El HSM Interceptor")){//El pirata esta listo para irse
            s.clone(ServerOperation.simulation.getReal2());
            ServerOperation.simulation.getReal2().setState("Viajando");
            s.setState("Viajando");
        }
        
        
        if(s.getState().equals("Viajando")){//El agente se mueve entre máquinas
            if(s.getWorldID()==Utils.parseInt(miNumero)){
                System.out.println("si");
                if( s.getName().equals("La Venganza Errante")){//es un pirata
                    ServerOperation.simulation.getPirata().cloneToLocal(s);
                    ServerOperation.simulation.getPirata().setState("Viaje completo");
                    s.setState("Viaje completo");
                    ServerOperation.simulation.getPirata().setHandler(Simulation.handler); 
                }
                if(s.getName().equals("El HSM Invencible")){//es parte de la armada real
                    ServerOperation.simulation.getReal1().cloneToLocal(s);
                    ServerOperation.simulation.getReal1().setState("Viaje completo");
                    s.setState("Viaje completo");
                    ServerOperation.simulation.getReal1().setHandler(Simulation.handler);
                    System.out.println( ServerOperation.simulation.getReal1());
                }
                if( s.getName().equals("El HSM Interceptor")){//es parte de la armada real
                    ServerOperation.simulation.getReal2().cloneToLocal(s);
                    ServerOperation.simulation.getReal2().setState("Viaje completo");
                    s.setState("Viaje completo");
                    ServerOperation.simulation.getReal2().setHandler(Simulation.handler);
                }  
            }
        }
        
        //Alguno de mis propios agentes
        s.ejecuta();
        
    }
    //--------------------------------------------------------------------------------
    @Override
    public void recibe(LinkedList<Ship> s) throws RemoteException {
        
        s.forEach((barco) -> {
            System.out.println("*****AAAAAAAAAAAAEl Barco " +barco.getName() + " ha llegado.*****");
            try {
                barco.ejecuta() ;
            } catch (RemoteException ex) {
                System.out.println("Hubo un error al tratar de ejecutar el barco: "+barco.getName());
            }
        });
    }
    //--------------------------------------------------------------------------------------
    
    public static void main(String[] args){
        
        miNumero = JOptionPane.showInputDialog("Numero del Servidor");
        miNombre = miNombre + miNumero;
        
        try {
            //System.setSecurityManager(new SecurityManager());
            //SecurityManager securityManager = System.getSecurityManager();
            registro = LocateRegistry.getRegistry(puertoRMI);
            
            try{
                
                registro.rebind(miNombre, new ServerOperation());
            }catch(RemoteException e){
                System.out.println("Comenzando rmiregistry en el puerto: "+puertoRMI);
                LocateRegistry.createRegistry(puertoRMI);
                
                registro.rebind(miNombre, new ServerOperation());
            }
            System.out.println(miNombre + " listo!");
            System.out.println("Servidores conectados actualmente: "+Arrays.toString(registro.list()));
            simulation = new Simulation(miNombre,720,600,miNumero);
            simulation.start();
        } catch (RemoteException e) {
            System.err.println("Server exception: " + e.toString());
        }
    }

}