/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities.item;

import dev.piratasenelcaribe.client.gfx.Assets;
import entities.Entity;
import java.awt.Graphics;

/**
 *
 * @author suber
 */
public class Tunnel extends Entity{
    protected int connectsWorldID;
    public static final int DEFAULT_WIDTH =80,DEFAULT_HEIGHT = 65;

    public Tunnel(int connectsWorldID, float x, float y, int worldID, String Name) {
        super(x, y, worldID, Name, DEFAULT_WIDTH, DEFAULT_HEIGHT);
        this.connectsWorldID = connectsWorldID;
        if(worldID==1 && connectsWorldID==2)
            this.texture=Assets.tder;
        else if(worldID==1 && connectsWorldID==4)
            this.texture=Assets.tab;
        else if(worldID==2 && connectsWorldID==3)
            this.texture=Assets.tab;
        else if(worldID==2 && connectsWorldID==1)
            this.texture=Assets.tizq;
        else if(worldID==3 && connectsWorldID==4)
            this.texture=Assets.tizq;
        else if(worldID==3 && connectsWorldID==2)
            this.texture=Assets.tarr;
        else if(worldID==4 && connectsWorldID==1)
            this.texture=Assets.tarr;
        else if(worldID==4 && connectsWorldID==3)
            this.texture=Assets.tder;
    }

    
    @Override
    public void tick() {
    }

    @Override
    public void tick(int x, int y) {
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(texture, (int)x, (int)y,width,height, null);
       //g.fillRect((int)r.getX(), (int)r.getY(), (int)r.getWidth(), (int)r.getHeight());
    }
    
}
