/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities.ship;

import dev.piratasenelcaribe.client.Handler;
import dev.piratasenelcaribe.client.gfx.Assets;
import entities.Entity;
import entities.island.Calamity;
import entities.island.Island;
import entities.item.Treasure;
import java.awt.Graphics;
import java.rmi.AccessException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.LinkedList;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.util.logging.Level;
import java.util.logging.Logger;
import rmiinterface.InterfazBarco;
import server.serverinterface.ServerInterface;

/**
 *
 * @author suber
 */
public class Ship extends Entity implements InterfazBarco{
    
    protected final String Kind;
    protected int tripulacion,startTrip=0;
    protected int raciones;
    protected int municiones;
    public static final float DEFAULT_SPEED = 3.0f;
    public static final int DEFAULT_WIDTH =90,DEFAULT_HEIGHT = 75;
    protected float velocidad;
    protected String state;
    protected Chest chest;
    protected String origen,destino;
    protected long arrive=0,end=0;
    protected boolean island=false;
    
    protected transient Handler handler;
    
    protected float xMove,yMove;

   int indiceNodo; // cuál es el siguiente ordenador a visitar
   LinkedList listaNodos; // el itinerario
   int puertoRMI = 12345 ;

    public int getRaciones() {
        return raciones;
    }

    public int getMuniciones() {
        return municiones;
    }

    public int getTripulacion() {
        return tripulacion;
    }

    public void setRaciones(int raciones) {
        this.raciones = raciones;
    }

    public void setMuniciones(int municiones) {
        this.municiones = municiones;
    }

    public void setTripulacion(int tripulacion) {
        this.tripulacion = tripulacion;
        if(this.startTrip==0){
            this.startTrip=tripulacion;
        }
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    
   
    public Ship( float x, float y, int worldID, String name,String Kind,LinkedList laListaComputadoras,int elPuertoRMI) {
        super(x,y,worldID,name, DEFAULT_WIDTH,DEFAULT_HEIGHT);
        this.Kind=Kind;
        this.velocidad = DEFAULT_SPEED;
        this.xMove=0;
        this.yMove=0; 
        this.listaNodos=laListaComputadoras;
        this.puertoRMI=elPuertoRMI;
        this.indiceNodo=0; 
        
        if(this.Kind.equals("Pirata")){
            this.chest=new Chest(this.worldID,100);
        }else{
            this.chest=new Chest(this.worldID,50);
        }
        this.state="creado";
        
    }
    public Ship( float x, float y, int worldID, String name,String Kind,LinkedList laListaComputadoras,int elPuertoRMI,String origen,Handler handler) {
        super(x,y,worldID,name, DEFAULT_WIDTH,DEFAULT_HEIGHT);
        this.Kind=Kind;
        this.velocidad = DEFAULT_SPEED;
        this.xMove=0;
        this.yMove=0; 
        this.listaNodos=laListaComputadoras;
        this.puertoRMI=elPuertoRMI;
        this.indiceNodo=0;
        this.origen=origen;
        this.destino="";    
        
        if(this.Kind.equals("Pirata")){
            this.chest=new Chest(this.worldID,100);
        }else{
            this.chest=new Chest(this.worldID,50);
        }
        this.state="creado";
        this.handler=handler;
    }
    public Ship( float x, float y, int worldID, String name,String Kind,LinkedList laListaComputadoras,int elPuertoRMI,String origen) {
        super(x,y,worldID,name, DEFAULT_WIDTH,DEFAULT_HEIGHT);
        this.Kind=Kind;
        this.velocidad = DEFAULT_SPEED;
        this.xMove=0;
        this.yMove=0; 
        this.listaNodos=laListaComputadoras;
        this.puertoRMI=elPuertoRMI;
        this.indiceNodo=0;
        this.origen=origen;
        this.destino="";    
        
        if(this.Kind.equals("Pirata")){
            this.chest=new Chest(this.worldID,100);
        }else{
            this.chest=new Chest(this.worldID,50);
        }
        this.state="creado";
    }
    public Ship( float x, float y, int worldID, String name,String Kind,LinkedList laListaComputadoras,int elPuertoRMI,String origen,String destino,Handler handler) {
        super(x,y,worldID,name, DEFAULT_WIDTH,DEFAULT_HEIGHT);
        this.Kind=Kind;
        this.velocidad = DEFAULT_SPEED;
        this.xMove=0;
        this.yMove=0; 
        this.listaNodos=laListaComputadoras;
        this.puertoRMI=elPuertoRMI;
        this.indiceNodo=0;
        this.origen=origen;
        this.destino=destino; 
        
        if(this.Kind.equals("Pirata")){
            this.chest=new Chest(this.worldID,100);
        }else{
            this.chest=new Chest(this.worldID,50);
        }
        this.state="creado";
        this.handler=handler;
    }
    
    public void next(String siguiente, String actual)throws RemoteException {
        siguiente = (String) listaNodos.get(indiceNodo);
            
        Registry registro=LocateRegistry.getRegistry("localhost",puertoRMI);
        ServerInterface h;
        try {
            System.out.println("Buscando "+siguiente+" en "+actual+" completado");
            h = (ServerInterface) registro.lookup(siguiente);
            h.recibe(this);
        }catch(RemoteException | NotBoundException ex){
            System.out.println("Error al mandar el agente "+this.getName()+ " a "+siguiente); 
            listaNodos.remove(siguiente);
            indiceNodo=0;
            siguiente = (String) listaNodos.get(indiceNodo);
            indiceNodo++;
            if(siguiente.equals(actual) && listaNodos.size()==1){
                listaNodos.remove(actual);
            }else if(indiceNodo<listaNodos.size()){
                next(siguiente,actual);
            }else{
                indiceNodo=0;
                next(siguiente,actual);
            }
        }
    }
    @Override
    public void ejecuta() throws RemoteException {
        String actual,siguiente;
        System.out.println("El barco ha llegado: "+this.getName());
        actual = (String) listaNodos.get(indiceNodo);
        
        indiceNodo++;
        if(indiceNodo<listaNodos.size()){
            
                siguiente = (String) listaNodos.get(indiceNodo);
            try {    
                Registry registro=LocateRegistry.getRegistry("localhost",puertoRMI);
                ServerInterface h= (ServerInterface) registro.lookup(siguiente);
                
                System.out.println("Buscando "+siguiente+" en "+actual+" completado");
               
                h.recibe(this);
            } catch (NotBoundException | AccessException ex) {
                Logger.getLogger(Ship.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            indiceNodo=0;
            siguiente = (String) listaNodos.get(indiceNodo);
            try {    
                Registry registro=LocateRegistry.getRegistry("localhost",puertoRMI);
                ServerInterface h= (ServerInterface) registro.lookup(siguiente);
                
                System.out.println("Buscando "+siguiente+" en "+actual+" completado");
               
                h.recibe(this);
            } catch (NotBoundException | AccessException ex) {
                Logger.getLogger(Ship.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
    }
    
    public void move(){
        x += xMove;
        y += yMove;
    }
    public float getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(float velocidad) {
        this.velocidad = velocidad;
    }

    public float getxMove() {
        return xMove;
    }

    public void setxMove(float xMove) {
        this.xMove = xMove;
    }

    public float getyMove() {
        return yMove;
    }

    public void setyMove(float yMove) {
        this.yMove = yMove;
    }

    @Override
    public String getName() {
        return Name;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public Chest getChest() {
        return chest;
    }
     public String info(){
         return "Barco: "+this.getName()+"\n";
     }

    public String getState() {
        return state;
    }
    

    private void checkMaps() {
        Treasure map=this.getChest().searchMap(origen,destino);
        if(map!=null){
            this.destino=map.getMap().getPoint2();
            this.velocidad=this.velocidad/(map.getMap().getDistance()/10);
            System.out.println("origen:"+this.origen);
            System.out.println("destino:"+this.destino);
        }
    }
    
    public boolean tick(int x,int y,int worldID) throws RemoteException {
        if(this.worldID!=handler.getWorld().worldId)return false;
        if(this.state.equals("Viaje completo")){
           this.setX(handler.getWorld().t_vuelta.getX());
            this.setY(handler.getWorld().t_vuelta.getY());
            this.setState("listo");
        }
        xMove=yMove=0;
        //Logica de la simulacion
        //se busca un destino
        int xi=0,yi=0;
        if("".equals(destino)){
            
            checkMaps();
        }else{//Ya se tiene un destino
            boolean band=false;
            
            
            for(Island i:handler.getWorld().getIslands()){
                if(i.getName().equals(destino)){
                    band=true;
                    xi =(int) i.getR().getX();
                    yi =(int) i.getR().getY();
                }
            }
            if(band){//la isla del mapa está en esta maquina
                System.out.println("entre aqui"+this.destino);
                if(Math.floor(this.y)!=(int)yi || Math.floor(this.x)!=(int)xi){
                    if(this.y>(int)yi){
                        yMove=-this.velocidad;
                    }
                    if(this.y<(int)yi){
                        yMove=this.velocidad;
                    }

                    if(this.x>(int)xi){
                        xMove=-this.velocidad;
                    }
                    if(this.x<(int)xi){
                        xMove=this.velocidad;
                    }
                }else if (Math.floor(this.y)==(int)yi && Math.floor(this.x)==(int)xi){
                    if(!island){
                        island=true;
                        arrive=System.nanoTime();
                        Island aux=this.handler.getWorld().getIslands()[0];//solo porquesi
                        //Logica de agarrar el tesoro y las calamidades
                        //solo se hara una vez ya que luego island se vuelve true
                        for(Island i:this.handler.getWorld().getIslands()){
                            if(i.getName().equals(this.destino))
                                aux=i;
                        }
                        //Si estan en la base de cada quien
                        if((destino.equals("Isla Nueva Esperanzas") && this.Kind.equals("Pirata")) || (destino.equals("Isla La Holandesa") && this.Kind.equals("Armada Real"))){
                            for(Treasure t:this.getChest().getArray()){
                                if(t!=null){
                                    if(!t.getName().equals("Mapa")){
                                        aux.getLocalChest().addElement(t);
                                    }
                                }
                            }
                            Chest auxc=this.getChest();
                            int index=0;
                            for(Treasure t:this.getChest().getArray()){
                                if(t!=null){
                                    if(t.getName().equals("Mapa")){
                                        auxc.addElement(t);
                                    }
                                    index++;
                                }
                                
                            }
                            this.chest=auxc;
                            this.tripulacion=this.startTrip;
                            origen=destino;
                            destino="";
                        }else{
                            //Primero cobrar el costo por desembarcar
                            
                            this.tripulacion=this.tripulacion-aux.getCostoTri();
                                      
                            this.municiones=this.municiones-aux.getCostoMun();
                            
                            //--------------------------------------
                            Treasure[] aux1;
                            int index=0;
                            aux1=new Treasure[30];
                            //Una primera corrida para agarrar los mapas
                            for(Treasure t:aux.getLocalChest().getArray()){
                                if(t!=null){
                                    if(t.getName().equals("Mapa")){
                                        this.getChest().addElement(t);
                                        aux1[index]=t;
                                    }
                                    index++;
                                }
                                
                            }
                            for (int i = 0; i < aux1.length; i++) {
                                if(aux1[i]!=null){
                                    aux.getLocalChest().remove(i);
                                }    
                            }
                            
                            index=0;
                            aux1=new Treasure[30];
                            //Una Segunda para buscar el diamante
                            for(Treasure t:aux.getLocalChest().getArray()){
                                if(t!=null){
                                  if(t.getName().equals("El Corazón de la Princesa")){
                                    if(!this.getChest().addElement(t)){
                                        aux1[index++]=this.getChest().getElement(this.getChest().getArray().length-1);
                                        this.getChest().remove(this.getChest().getArray().length-1);
                                        
                                        aux1[index++]=this.getChest().getElement(this.getChest().getArray().length-1);
                                        this.getChest().remove(this.getChest().getArray().length-1);
                                        
                                        
                                        this.getChest().addElement(t);
                                    }
                                }  
                                }
                                
                            }                                    
                            for (Treasure aux11 : aux1) {
                                if (aux11 != null) {
                                    aux.getLocalChest().addElement(aux11);
                                }    
                            }
                            aux1=null;
                            
                            //Calamidades
                            
                            Calamity c = aux.applyRandomCalamity();
                            if(c!=null){
                                String type = c.getType();
                                int damage = c.getDamage();
                                System.out.println("Has sufrido:"+c.getName());
                                
                                switch (type) {
                                    case "Suministros":
                                        this.raciones=this.raciones*(1-(damage/10));
                                        break;
                                    case "Hombres":
                                        this.tripulacion=this.tripulacion*(1-(damage/10));
                                        break;
                                    default:
                                        this.municiones=this.municiones*(1-(damage/10));
                                        break;
                                }
                            }
                            //-------------------------------
                        }
                        
                        //-------------------------------------------
                    }else if((System.nanoTime()-arrive)>=2000000000){
                        end++;
                        if(end>=2){
                            System.out.println("ya te deberias ir we");
                            origen=destino;
                            destino="";
                            end=0;
                            arrive=0;
                            island=false;
                            this.velocidad=DEFAULT_SPEED;
                            if(this.tripulacion<=this.startTrip/3){
                                this.velocidad=2;
                                if(this.Kind.equals("Pirata")){
                                    destino="Isla Nueva Esperanzas";
                                }else{
                                    destino="Isla La Holandesa";
                                }
                            }
                        }
                    }    
                }
            }else{//la isla no esta en el mapa, hay que dirigirse al tunel para viajar
                xi =(int) handler.getWorld().t_ida.getR().getX();
                yi =(int) handler.getWorld().t_ida.getR().getY();
                if(Math.floor(this.y)!=(int)yi || Math.floor(this.x)!=(int)xi){
                    if(this.y>(int)yi){
                        yMove=-this.velocidad;
                    }
                    if(this.y<(int)yi){
                        yMove=this.velocidad;
                    }

                    if(this.x>(int)xi){
                        xMove=-this.velocidad;
                    }
                    if(this.x<(int)xi){
                        xMove=this.velocidad;
                    }
                }else if (Math.floor(this.y)==(int)yi  && Math.floor(this.x)==(int)xi){
                    System.out.println("debes viajar");
                    
                    if((this.worldID+1)>4)this.worldID=1;
                    else this.worldID=this.worldID+1;     
                    
                    this.setState("En espera para viajar");
                }
            }
        }
        this.y=(int) (this.y+yMove);
        this.x=(int) (this.x+xMove);
        this.r.setRect(this.getR().getX()+xMove, this.getR().getY()+yMove, width, height);

        //------------
        if(this.hover(x,y)){
            System.out.println(this.info());
        }
        return true;
    }
    
    public void render(Graphics g,int worldID) {
        if(worldID==this.worldID){
            if(texture!=null) {
                g.drawImage(texture, (int)x, (int)y, width, height, null);
                
            }
            //g.fillRect((int)this.r.getX(), (int)this.getR().getY(),(int)this.getR().getWidth(),(int) this.getR().getHeight());
        }
    }

    //METODOS DE LA CLASE ENTIDAD PERO NO SON NECESARIOS YA QUE LA INTERFAZ LOS SOBREESCRIBE
    @Override
    public void tick() {
    } 

    @Override
    public void tick(int x, int y) {
    }

    @Override
    public void render(Graphics g) {
    }

    @Override
    public void clone(Ship s) throws RemoteException {
        this.chest=s.chest;
        this.destino=s.destino;
        this.indiceNodo=s.indiceNodo;
        //this.listaNodos=s.listaNodos;
        this.municiones=s.municiones;
        this.origen=s.origen;
        this.puertoRMI=s.puertoRMI;
        this.r=s.r;
        this.raciones=s.raciones;
        this.state=s.state;
        //this.texture=s.texture;
        this.tripulacion=s.tripulacion;
        this.velocidad=s.velocidad;
        this.width=s.width;
        this.worldID=s.worldID;
        this.x=s.x;
        this.y=s.y;
        this.xMove=s.xMove;
        this.yMove=s.yMove;
    }
    public void cloneToLocal(Ship s) throws RemoteException {
        this.chest=s.chest;
        this.destino=s.destino;
        this.indiceNodo=s.indiceNodo;
        //this.listaNodos=s.listaNodos;
        this.municiones=s.municiones;
        this.origen=s.origen;
        this.puertoRMI=s.puertoRMI;
        this.r=s.r;
        this.raciones=s.raciones;
        this.state=s.state;
        //this.texture=s.texture;
        this.tripulacion=s.tripulacion;
        this.velocidad=s.velocidad;
        this.width=s.width;
        this.worldID=s.worldID;
        this.x=s.x;
        this.y=s.y;
        this.xMove=s.xMove;
        this.yMove=s.yMove;
        System.out.println("aaaaaaaaaaaaaas");
        if("Pirata".equals(this.Kind))
            this.texture=Assets.pirataD;
        else
            this.texture=Assets.realD;
    }

    @Override
    public void setState(String s) throws RemoteException {
        this.state=s;
    }

    
}
