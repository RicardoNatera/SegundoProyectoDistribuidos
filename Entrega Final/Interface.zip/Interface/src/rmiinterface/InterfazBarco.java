/*
 * Interfaz del Barco
 */
package rmiinterface;

import entities.ship.Ship;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 */

public interface InterfazBarco extends Remote{
    void ejecuta() throws RemoteException;
    void clone(Ship s) throws RemoteException;
    void setState(String s) throws RemoteException;
}
